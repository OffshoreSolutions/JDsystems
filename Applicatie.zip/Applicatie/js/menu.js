$(document).on("pagecreate","body",function(){

$("#menu,#menu-black").click(function(){
if ($("nav").hasClass("open")) {
  $("nav").animate({"left": "0"},100);
  $("nav").addClass("gesloten");
  $("nav").removeClass("open");
}

else {
	$("nav").animate({"left": "-160px"});
	$("nav").addClass("open");
    $("nav").removeClass("gesloten");
}
});
});
$(document).on("pagecreate","body",function(){
  $("nav,#generated-images,header,.touch-enabled").on("swiperight",function(){
if ($("nav").hasClass("open")) {
  $("nav").animate({"left": "0"},100);
  $("nav").addClass("gesloten");
  $("nav").removeClass("open");
}
  });                       
});
$(document).on("pagecreate","body",function(){
  $("nav,#generated-images,header,.touch-enabled").on("swipeleft",function(){
if ($("nav").hasClass("gesloten")) {
  $("nav").animate({"left": "-160"},100);
  $("nav").addClass("open");
  $("nav").removeClass("gesloten");
}
  });                       
});
